package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.dao.MemberDao;
import com.kh.model.vo.Member;

import co.kh.view.MemberView;

/*
	 * * Controller
	 * 
	 * - View에서 요청한 기능을 처리함
	 * - View의 해당 메소드로 전달된 데이터를 가공처리 한 후 DAO 메소드 호출시 전달
	 * - DAO로부터 반환받은 결과에 따라 사용자가 보게될 응답화면 view 결정
	 * 
	 * * Controller 메소드 코드 흐름
	 * 1) 매개변수로 전달받은 값들을 하나의 VO 객체에 담기(가공처리)
	 * 2) DAO단의 메소드를 호출하면서 VO 객체를 전달 후 결과 받기
	 * 3) DAO로부터 전달받은 결과에 따라서 응답화면을 지정
	 * 
	 */

public class MemberController {
	
	/**
	 * 사용자의 회원추가 요청을 처리하는 메소드
	 * @param userId
	 * @param userPwd
	 * @param userName
	 * @param gender
	 * @param age
	 * @param email
	 * @param phone
	 * @param address => 사용자가 회원 추가 요청시 입력했던 값들
	 */
	public void insertMember(String userId, String userPwd,
							 String userName, String gender,
							 int age, String email,
							 String phone, String address) {
		
		// 1) 전달된 데이터들을(매개변수) vo의 Member 객체로 가공하기
		Member m = new Member(userId, userPwd, userName, gender, age,
								email, phone, address);
		
		// 2) 가공된 Member 객체를 DAO의 메소드로 넘기면서 호출 및 그 결과값을 DAO로부터 받기
		int result = new MemberDao().insertMember(m);
		
		// 3) 결과에 따른 응답화면 지정
		if(result > 0) { // 성공, 성공화면 --> View에서 메소드 정의 후 호출
			
			new MemberView().displaySuccess("회원 추가 성공");
			
		} else { // 실패, 실패화면 --> View에서 메소드 정의 후 호출
			
			new MemberView().displayFail("회원 추가 실패");
			
		}
		
	} // insertMember 메소드 끝.
	
	/**
	 * 사용자의 회원전체조회 요청을 처리해주는 메소드
	 */
	public void selectAll() {
		
		// 1) 전달된 데이터들을 Member 객체로 가공 ==> 없으면 패스
		
		// 2) DAO로 메소드 호출 후 결과받기
		// 요청시 전달값이 없어서 매개변수 없이 그냥 호출
		// SELECT문을 이용한 조회 기능은 크게 2가지로 나뉨
		// - 여러행 조회: 2개 이상의 데이터가 조회될 경우(ArrayList)
		// - 단일행 조회: 많아봤자 최대 1개 데이터가 조회될 경우(VO)
		ArrayList<Member> list = new MemberDao().selectAll();
		
		// 3) 결과에 따른 응답화면 지정
		// > 조회결과 유무 판별 후 사용자가 보게 될 화면을 각각 지정
		if(list.isEmpty()) {
			
			new MemberView().displayNodata("전체 조회된 결과가 없습니다.");
			
		} else {
			
			new MemberView().displayList(list);
			
			
		}
		
	} // selectAll 메소드 끝.

}

















