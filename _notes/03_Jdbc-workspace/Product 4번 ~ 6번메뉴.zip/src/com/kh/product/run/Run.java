package com.kh.product.run;

import com.kh.product.view.ProductView;

public class Run {

	/**
	 * 메인메소드, 프로그램 실행
	 * @param args
	 */
	public static void main(String[] args) {
		
		new ProductView().mainMenu();

	}

}
