package com.kh.product.view;

import java.util.ArrayList;
import java.util.Scanner;

import com.kh.product.controller.ProductController;
import com.kh.product.vo.Product;

public class ProductView {
	
	private Scanner sc = new Scanner(System.in);
	private ProductController pc = new ProductController();
	
	/**
	 * 메인메뉴 출력화면 
	 */
	public void mainMenu() {
		
		while(true) {
			
			System.out.println("4. 제품 삭제");
			System.out.println("5. 품명 검색");
			System.out.println("6. 브랜드 검색");
			System.out.println("0. 프로그램 종료");
			
			System.out.print("메뉴 입력: ");
			int menu = sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1:
				
				break;
			case 2:
				
				break;
			case 3:
				
				break;
			case 4:
				deleteProduct();
				break;
			case 5:
				selectByName();
				break;
			case 6:
				selectByBrand();
				break;
			case 0:
				System.out.println("프로그램 종료");
				return;
			default:
				System.out.println("다시 입력하세요.");	
			
			}
			
		}
		
	} // mainMenu 끝.
	
	
	/**
	 * 제품 삭제시 보일 화면 메소드. 코드로 입력해서 삭제
	 */
	public void deleteProduct() {
		
		System.out.println("---제품삭제---\n");
		
		System.out.print("삭제할 제품(코드입력): ");
		String prCode = sc.nextLine();
		
		pc.deleteProduct(prCode);
		
	} // deleteProduct 메소드 끝.
	
	/**
	 * 품명으로 검색, 제품 검색시 보일 화면 메소드. 키워드로 입력해서 한 글자만 같아도 검색됨
	 */
	public void selectByName() {
		
		System.out.println("---품명검색---\n");
		
		System.out.print("검색할 품명: ");
		String nameKeyword = sc.nextLine();
		
		pc.selectByName(nameKeyword);
		
	} // selectByName 메소드 끝.
	
	/**
	 * 브랜드명으로 검색, 제품 검색시 보일 화면 메소드. 키워드로 입력해서 한 글자만 같아도 검색됨
	 */
	public void selectByBrand() {
		
		System.out.println("---브랜드검색---\n");
		
		System.out.println("검색할 브랜드: ");
		String brandKeyword = sc.nextLine();
		
		pc.selectByBrand(brandKeyword);
		
	} // selectByBrand 메소드 끝.
	
	/**
	 * 요청 성공시 보일 화면 메소드.
	 * @param message => Controller에서 출력해줄 화면
	 */
	public void displaySuccess(String message) {
		
		System.out.println(message);
	}
	
	/**
	 * 요청 실패시 보일 화면 메소드.
	 * @param message => Controller에서 출력해줄 화면
	 */
	public void displayFail(String message) {
		
		System.out.println(message);
	}
	
	/**
	 * 조회된 결과가 없을 시 보일 화면 메소드
	 * @param message => Controller에서 출력해줄 화면
	 */
	public void displayNoData(String message) {
		
		System.out.println(message);
	}
	
	/**
	 * 조회된 결과가 있을 시 보일 화면 메소드
	 * @param list => 검색된 상품 리스트 담겸있음
	 */
	public void displayList(ArrayList<Product> list) {
		
		System.out.println("검색된 건은 총 " + list.size() + "건 입니다.");
	
		for(Product p : list) {
			
			System.out.println(p);
		}
	}
	

}
